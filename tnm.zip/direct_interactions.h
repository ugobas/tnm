int Interactions_direct(struct interaction *Int_list, 
			atom *atoms, int N_atoms);
float DELTA_DIR;
