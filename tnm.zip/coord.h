
// #define L_MAX 40000       /* Maximal length of a chain */

#define CHMAX 800          // Maximum number of chains

typedef struct {
  // Read from PDB
  float r[3];
  float B_factor;
  char name[4];
  float anisou[3][3];
  float occupancy;
  // main chain or side chain?
  int main;
  // Connections
  int i_next, i_num;
  int ali;
  // Degrees of freedom
  int last_dof_rigid; // New!
  int last_dof_main;  // last  main-chain DoF
  int last_dof_side;  // last  side-chain DoF
  //int first_dof_main; // New!!
  //int first_dof_side; // first side-chain DoF
  // Interactions
  int N_int;
  // Residue
  int res;
  char aa;
  int chain;
} atom;

struct axe{
  char type;                  // l=length a=angle other=torsion
  int atom1, atom2;           // atoms that define the axe
  struct bond *bond;          // Bond associate with the axe
  atom *atom;                 // Last atom
  //int res;                    // Residue of last atom
  //int chain;                  // chain of last atom
  int first_atom;             // first and last atoms moved by the axe
  int last_atom;
  int first_kin;              // first reference atom moved by the axe
  int last_kin;
  int last_main;              // Last main chain degree of freedom
  int first_side;             // First side chain degree of freedom
  int first_main;             // First main chain degree of freedom (new)
  int last_rigid;             // Last rigid body degree of freedom (new)
  int previous;
  double offset[3];           // origin of the axis
  double rot[3];              // rotation
  double shift[3];            // translation (remember, minus sign)
  double vers[3];             // axe versor
  double global_shift[3];     // Rigid body translation
  double global_rot[3];       // Rigid body rotation
  double local_shift[3];      // Rb translation - shift
  double local_rot[3];        // Rb rotation + rot
  double mass;
  double MR[3];
  double I[3][3];
};

struct interaction{
  int i1, i2; // atom2 > atom1
  int res1, res2;
  float r2, sec_der;
  int type;
};

struct residue{
  atom *atom_ptr;
  int n_atom;
  char chain;
  char pdbres[6];
  char amm;
  short i_aa;
  short exo;
  short type;     // Poly: AA=1, RNA=2, DNA=3, other=0, Single: *-1
  short n_cont;
  float asa;
  //float PE;
  //float B_factor;
  //float B_NM;
};

struct chain{
  int ini_atom;
  int natoms;
  int last_rigid;
  int ini_main;
  int mainaxes;
  int ini_side;
  int nsides;
  int ini_res;
  int nres;
  //int nref;
  int ini_cart;
  int ncart;
  int type;   // Polymer: AA=1, RNA=2, DNA=3, other=0; Monomer: -1
  int last_atom;
  int last_ref;
  char label;
  int *alignres;
  int match;
  struct residue *res;
  char *seq;     // Only structured residues
  char *seqres;  // SEQRES record
  int N_seqres;
  int *ali_seqres;
};

struct molecule{
  atom *atoms;
  int natoms;
  double *atom_str;
  int N_ref, N_cart;
  struct residue *seq;
  int nres;
  int N_diso;
  struct chain *chains;
  char chain[CHMAX];
  int Nchain;
  struct interaction *Int_list;
  int N_int;
  struct Reference *Ref;
  struct axe *axe;
  int naxe;
  char name[100];
  char pdbid[100];
  int ANISOU, nmr;
};

#define FILE_MSG   "message.out"


int Verbose;
char cont_type;
float cont_thr, cont_thr2;


short **Compute_map(int N_res, struct residue *seq, int *N_cont);
void Average_B(struct residue *seq, int N);
int Is_atom_main(char *name, int seq_type);
int Code_AA(char res);
char *AA_code;
