// Reference atoms
#define ALL_AXES_DEF 1 // If 0, first phi and last psi angles excluded
#define SEL_DEF "CA"
char REF[20];

int HYD; // Are hydrogen atoms considered?
int HYD_REF;

// defaulta values for interaction thresholds
#define THR_A_MIN   9.0   //7.0
#define THR_A_MAX   9.0    //14.0
#define THR_A_STEP  1.0
#define THR_B_MIN   9.0   // 7.0
#define THR_B_MAX   9.0   // 14.0
#define THR_B_STEP  1.0
#define THR_C_MIN   5.0   // 4.0
#define THR_C_MAX   5.0   // 7.0
#define THR_C_STEP  0.5

#define THR_A 9.0
#define THR_B 9.0
#define THR_C 4.5

// Rescale Hessian components by r^-EXP_HESSIAN ?
float EXP_HESSIAN;

#define N_MODES_DEF 0 // Lowest frequency modes printed
int N_MODES;

#define E_MIN_DEF   0.00001  // Minimum eigenvalue 
//#define E_MIN_DEF   0.000000001  // Minimum eigenvalue 

#define VERBOSE 1      /* Set to one for more output */
#define KINETIC_DEF 1 // If(KINETIC), compute T_inv
int KINETIC;      // Considering kinetic energy in tnm model

#define PRINT_LAMBDA_DEF 0
int PRINT_LAMBDA; // Printing list of eigenvalues

float E_MIN;  // Minimum eigenvalue allowed for normal modes

#define ANISOU_DEF 0 // Examine anisotropic temperature factors?
int ANISOU;

// Hydrogen bonds
#define ENE_HB_DEF 2.0  // Ratio between HB interactions and other types
float ENE_HB;
#define DA_THR_DEF    3.5    // Max donor-acceptor dist in h bond
float DA_THR;
#define COS_DAA_DEF  -0.08   // Max cos(A'AD) (min. 105 degrees)
float COS_DAA;

#define THR_NO_DEF 4.0   // Threshold for NO interactions
float THR_NO;

#define N_INT_TYPE 4  // if 4, computes also hydrogen bonds
// Interactions types: 1=CA, 2=CB, 3=all, 4=HB

#define FIT_ROT 0 // Include global rotations in B factors fit? (3 param)

#define PRINT_AXES_DEF 1
int PRINT_AXES;

int COMPARE;
