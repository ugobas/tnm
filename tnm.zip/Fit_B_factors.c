#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "ridge_regression.h"
#include "vector.h"
#include "Fit_B.h"

int VERBOSE=0;

void Print_data(float **X, float *Y, int N, int Npar, char *nameout);
int Find_outliers_Z(int *outlier, float *y, int N, float sig);
int Find_outliers_mean(int *outlier, float *y, int N, float sig);

float Bfactors_fit(float *r, int *outlier, float *dof,
		   float *B_pred_all, float *B_PDB, float *B_ENM,
		   float *R_eq, int N, char *name, char type)
{
  /* It fits B factors as the combination of the internal motion
     predicted by the ENM and the rigid body motion dr_i = t+I X r_i,
     which leads to
     B^exp_i ~ A0 B^ENM_i + A1(translations) +
               A2*r_ix+A3*r_iy+A+A4*r_iz (rototranslation) +
	       A5*r_ix*r_ix+...A10*r_iz*r_iz (rotations)
     The 11 free parameters A0... A10 are fitted through ridge regression.

     OUTPUT file <name>_Bfact_fit.dat
     For each examined Lambda we report:
     Lambda, RangeRisk, GenCrossVal(Golub_etal_1979), Error, dE/dLambda, A0
     The program outputs results of three kinds of fit:
     (1) B^exp_i ~ A0 B^ENM_i + A1 (only translations, fit for Lambda=0)
     (2) 11 parameter fit for Lambda that minimizes RangeRisk (Mallows, 1973,
     as reported in Golub, Heath & Wahba 1979);
     (3) 11 parameters, for Lambda that maximizes the "specific heat"
     dE/dLambda (Bastolla, unpublished)
     For each fit (1), (2), (3) we report:
     Force constant (A0), Lambda, Relative error of the fit,
     Fraction of B^exp atributed to internal motion, fraction attributed to
     rotation and rototranslation.
   */


  int Npar=11, i, j=0;
  float **Xall=malloc(N*sizeof(float *));
  for(i=0; i<N; i++){
    Xall[i]=malloc(Npar*sizeof(float));
    float *x=Xall[i];
    x[0]=B_ENM[i]; x[1]=1;
    float rx=R_eq[j],ry=R_eq[j+1],rz=R_eq[j+2]; j+=3;
    x[2]=rx; x[3]=ry; x[4]=rz;
    x[5]=rx*rx; x[6]=rx*ry; x[7]=rx*rz;
    x[8]=ry*ry; x[9]=ry*rz; x[10]=rz*rz;
  }
  char nameout[100];
  sprintf(nameout, "%s_Bfact_fit", name);
  if(VERBOSE)Print_data(Xall, B_PDB, N, Npar, name);

  // Eliminate outliers
  for(i=0; i<N; i++)outlier[i]=0;
  int num=N; float sigma=2.5;
  num-=Find_outliers_mean(outlier, B_ENM, N, sigma); 
  num-=Find_outliers_mean(outlier, B_PDB, N, sigma);
  /*float sigma=3;
  num-=Find_outliers_Z(outlier, B_ENM, N, sigma); 
  num-=Find_outliers_Z(outlier, B_PDB, N, sigma);*/

  printf("%d outliers eliminated for B factors fit\n", N-num);
  float Y[num]; int k=0;
  float **X=malloc(num*sizeof(float *));
  for(i=0; i<N; i++){
    if(outlier[i])continue;
    X[k]=malloc(Npar*sizeof(float));
    float *x=X[k], *z=Xall[i];
    for(int a=0; a<Npar; a++)x[a]=z[a];
    Y[k]=B_PDB[i]; k++;
  }

  // Complete fit:
  // char type='M'; C= specific heat M= Max penalty
  printf("Fitting B factors with internal and rigid body motions\n");
  float D_out[Npar];
  struct ridge_fit fit; fit.A=malloc(Npar*sizeof(float));
  *r=Ridge_regression(&fit, B_pred_all, D_out, nameout,
		      X, Y, num, Npar, type);

  // Returned results
  for(i=0; i<N; i++){
    float *Xi=Xall[i]; double Yp=0;
    for(int a=0; a<Npar; a++)Yp+=Xi[a]*fit.A[a];
    B_pred_all[i]=Yp;
  }
  for(i=0; i<3; i++)dof[i]=fit.dof[i];
  float slope=fit.A[0];
  free(fit.A);
  for(i=0; i<N; i++)free(Xall[i]); free(Xall);
  for(i=0; i<num; i++)free(X[i]); free(X);
  return(slope);
}

void Print_data(float **X, float *Y, int N, int Npar, char *name){
  char nameout[100];
  sprintf(nameout, "%s_Bfact_data_fits.dat", name);
  FILE *file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  int a,i;
  /*float *norm=malloc(Npar*sizeof(float)); 
  for(a=0; a<Npar; a++){
    double sum=0;
    for(i=0; i<N; i++)sum+=X[i][a]*X[i][a];
    norm[a]=sqrt(sum/N);
    }*/
  fprintf(file_out, "#Y ENM const x y z xx xy xz yy yz zz\n");
  for(i=0; i<N; i++){
    fprintf(file_out, "%.3f\t",Y[i]);
    for(a=0; a<Npar; a++)fprintf(file_out, "%.3f\t",X[i][a]);
    fprintf(file_out, "\n");
  }
  fclose(file_out);
  //free(norm);
}

int Find_outliers_Z(int *outlier, float *y, int N, float sig){
  double y1=0, y2=0; float *yy=y; int i;
  for(i=0; i<N; i++){
    y1+=*yy; y2+=(*yy)*(*yy); yy++;
  }
  y1/=N; y2=y2-N*y1*y1; if(N>1)y2=sqrt(y2/(N-1));
  float max=y1+sig*y2, min=y1-sig*y2; int n=0;
  for(i=0; i<N; i++){
    if(outlier[i])continue;
    if((y[i]>max)||(y[i]<min)){outlier[i]=1; n++;}
  }
  return(n);
}

int Find_outliers_mean(int *outlier, float *y, int N, float sig){
  double y1=0; int i;
  for(i=0; i<N; i++)y1+=y[i];
  float max=sig*y1/N; int n=0;
  for(i=0; i<N; i++){
    if(outlier[i])continue;
    if(y[i]>max){outlier[i]=1; n++;}
  }
  return(n);
}

float Fit_no_outliers(int *outlier, float *XX, float *YY, int N,
		      float *slope, float *offset)
{
  int k=0; float X[N], Y[N];
  for(int i=0; i<N; i++){
    if(outlier[i])continue;
    X[k]=XX[i]; Y[k]=YY[i]; k++;
  }
  float r=Corr_coeff(X, Y, k, slope, offset);
  return(r);
}
