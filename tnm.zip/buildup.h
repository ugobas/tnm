
struct bond{
  atom *atom;
  float r[3];           // Coordinates of representative atom
  int i_atom;
  //char *name;
  //int chain;  
  //int res;
  //char type; // m= main chain, s= side chain, r= rigid body
  // Degrees of freedom
  int stored;
  struct bond *previous;
  //int ibond;
  int terminal;       // Is the bond at terminus of the molecule?
  int len;           // DoF associated with bond length
  int angle;         // DoF associated with bond angle
  int torsion;       // DoF associated with torsion, previous rot_axe
  // Internal coordinates
  float dr[3];          // dr - previous->dr
  double l;             // bond length |dr|;
  double r_cos_theta;   // l*cos(theta)
  double phi;           // arccos(cos_phi)
  short d_phi;          // Difference of phi in degrees
  float dy[3];          // cross product dr X previous->dr
  float dx[3];          // norm to dr in plane dr dr1
  float dz[3];          // Direction of dr
  //float ax, ay, az;     // Coordinates
};
struct bond *Set_bonds_topology(int N_atoms, atom *atoms, struct residue *seq);
int Set_bonds_measure(struct bond *bonds, int N_atoms, atom *atoms);
int Set_bonds_prot(struct bond *bonds, int N_atoms,
		   atom *atoms, struct axe *axes, int naxes);
void Build_up(struct bond *bonds, int N_atoms,
	      float *d_phi, int N_axes);
void Trajectory(atom *atoms, int natoms, struct axe *axes, int naxe,
		float **Tors_mode, int imode, float fact, int nmove,
		struct bond *bonds);
struct axe *Set_DegofFreed(int *naxe,     // Number of degrees of freedom
			   int *nmain,    // Number of mainaxes
			   int *nseed,    // Number of seed axes
			   int *nskip,    // Skipped mainaxes
			   int *N_diso,   // Number of disorder gaps
			   struct bond *bonds,  // Covalent topology
			   atom *atoms,   // Pointer to protein atoms
			   int natoms,    // Number of protein atoms
			   int *atom_ref, // Reference atoms
			   int N_ref,     // Pointer to ligand atoms
			   struct residue *res,  // residues
			   int nres,      // Number of residues
			   struct chain *chains, // chains
			   int Nchain,    // Number of chains
			   struct interaction *Int_list, // interactions
			   int N_int,     // Number of interactions
			   int MIN_INT_MAIN, // Min. interactions per dof
			   int MIN_INT_SIDE, // Min. interactions per dof
			   int OMEGA,     // Are Omega angles stored?
			   int SCHAIN,   // Are side chains used?
			   int PSI);     // Are psi angles used?
int D_omega_thr; // Omega unfrozen if D_omega>D_omega_thr


/*void Set_atom_axe(atom *atoms, struct chain *chains, int Nchain,
  struct axe *axes);*/
