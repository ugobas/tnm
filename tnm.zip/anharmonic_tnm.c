#include "coord.h"
#include "nma_para.h"
#include "tnm.h"
#include "buildup.h"
#include "McLachlan.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "simulation.h"

// Print_mode_PDB

int INI_RES_RES=0;
int **int_res1_res2;
float lambda2;

struct interaction *Int_list_ini; int N_int_ini;
struct interaction *Int_list_tmp; int N_int_tmp;

int INT_MAX;        // Maximum number of interactions tested
float d_CA_high=11; // Maximum distance in stored interactions
float dE_max=15;    // Maximum value of (omega*c)^2
float dE_step=0.01; // Step value of (omega*c)^2
float MAX_ANGLE=0.05; // Maximum allowed angular deviation
float RMSD_STEP=1.0;  // Interaction list computed when RMSD > RMSD_STEP

// Routines:
float Energy_anharmonic(float *r, atom *atoms, int nres,
			struct interaction *Int_list, int N_int);

int **Set_interactions(struct interaction *Int_list, int N_int,
		       atom *atoms, int Nres);
int Interactions_CA(struct interaction *Int_list, float thr,
		    atom *atoms, int N_res, float *coord);
int Find_CA(atom *atoms, int *i1, int res);
int Start_res(atom *atoms, int i);
float Min_res_dist(float *r, atom *atoms, int i1, int i2, int n);


float Anharmonicity(atom *atoms, int natoms,
		    struct axe *axe, int naxes,
		    struct bond *bonds,
		    struct residue *seq, int nres,
		    struct interaction *Int_list, int N_int,
		    float *Tors, float omega,
		    char *nameout, int ia)
{
  // Coordinates
  Set_bonds_measure(bonds, natoms, atoms);
  float mass[natoms]; Set_masses(mass,atoms,natoms);
  int n3=3*natoms, i;
  float coord_new[n3], coord_ini[n3], coord_ref[n3];
  int num_atom=Put_coord(coord_ini, bonds, natoms);
  if(num_atom!=natoms){
    printf("ERROR, different number of atoms in bonds (%d) and atoms (%d)\n",
	   num_atom, natoms); exit(8);
  }
  for(i=0; i<n3; i++){
    coord_new[i]=coord_ini[i]; coord_ref[i]=coord_ini[i];
  }
 
  N_int_tmp=N_int_ini;
  for(i=0; i<N_int_tmp; i++)Int_list_tmp[i]=Int_list_ini[i];
  float Ene_anhar_ini=
    Energy_anharmonic(coord_ini, atoms, nres, Int_list, N_int);
  float Ene_anhar, Ene_har;

  // Determine maximum possible factor for mode ia
  int nstep=dE_max/dE_step;
  float c_max=sqrt(dE_max)/omega;
  float c_step=c_max/nstep;
  float tmax=0;
  for(i=0; i<naxes; i++)if(fabs(Tors[i])>tmax)tmax=fabs(Tors[i]);
  if(c_step*tmax > MAX_ANGLE){
    printf("WARNING, max. d_theta allowed for mode %d = %.3f > %.3f\n",
	   ia, c_step*tmax, MAX_ANGLE);
    c_step=(MAX_ANGLE/tmax);
    nstep=c_max/c_step;
  }

  // Deformations along normal mode alpha
  float omega2=omega*omega/2;
  double Z=0, E_ave_har=0, E_ave_anhar=0;
  float rmsd_ini=0, rmsd_ref=0, rmsd_max=0, Ene_max=0;

  // Output file
  char out[200];
  sprintf(out, "%s_mode%d_energy.dat", nameout, ia);
  FILE *file_out=fopen(out, "w");
  printf("Writing harmonic and anaharmonic energy in %s\n", out);
  fprintf(file_out, "#Mode %d, 1/omega= %.3g ", ia, 1./omega);
  fprintf(file_out, "Max.ampl.= %.3g step=%.3g max.angle= %.3f nstep=%d\n",
	 c_max, c_step, c_step*tmax, nstep);
  fprintf(file_out, "#c_alpha rmsd Ene_harmonic Ene_noharmonic\n");
  //Print_PDB(file_out, atoms, natoms, coord1, seq, 0, 0.0);

  // The first step is shorter
  int back1=nstep+1;
  c_step/=2; float c_all=0;
  float d_phi[naxes];
  for(i=0; i<naxes; i++)d_phi[i]=Tors[i]*c_step;
  for(int step=0; step<=(2*nstep); step++){

    Build_up(bonds, natoms, d_phi, naxes);
    Put_coord(coord_new, bonds, num_atom);
    c_all+=c_step; 
    Ene_har=c_all*c_all*omega2;
    rmsd_ref= rmsd_mclachlan_f(coord_ref, coord_new, mass, num_atom);
    rmsd_ini= rmsd_mclachlan_f(coord_ini, coord_new, mass, num_atom);
    fprintf(file_out, "%.4g\t%.4g\t%.4g", c_all, rmsd_ini, Ene_har);

    if((step==1)||(step==back1)){
      c_step*=2; for(i=0; i<naxes; i++)d_phi[i]*=2;
    }else if(step==nstep){
      // change direction
      c_all=0; c_step=-c_step/2;
      for(i=0; i<naxes; i++)d_phi[i]=-d_phi[i]/2;
      for(i=0; i<n3; i++)coord_ref[i]=coord_ini[i];
      Set_bonds_measure(bonds, natoms, atoms);
      N_int_tmp=N_int_ini;
      for(i=0; i<N_int_tmp; i++)Int_list_tmp[i]=Int_list_ini[i];
      rmsd_max=rmsd_ini;
    }else if(rmsd_ref > RMSD_STEP){ //||((forward==0)&&(pdb==0))
      //pdb++;
      //Print_PDB(file_out, atoms, natoms, coord_new, seq, pdb, rmsd);
      for(i=0; i<n3; i++)coord_ref[i]=coord_new[i];
      N_int_tmp= 
	Interactions_CA(Int_list_tmp,d_CA_high,atoms,nres,coord_ref);
    }

    Ene_anhar=Energy_anharmonic(coord_new, atoms, nres, Int_list, N_int);
    Ene_anhar-=Ene_anhar_ini;
    fprintf(file_out, "\t%.4g\n", Ene_anhar);
    if(Ene_anhar > Ene_max)Ene_max=Ene_anhar;
    // Compute integral 
    float p=exp(-Ene_har);
    Z+=p; E_ave_har+=p*Ene_har; E_ave_anhar+=p*Ene_anhar;
    
  }
  if(rmsd_ini>rmsd_max)rmsd_max=rmsd_ini;
  E_ave_har/=Z; E_ave_anhar/=Z;
  float d_KL=E_ave_har-E_ave_anhar;
  fprintf(file_out,
	  "# <E_har>= %.4g analytical= %.4g dKL= <E_anhar-E_har> %.4g\n",
	  E_ave_har, E_ave_anhar, d_KL);
  fclose(file_out);

  int f_exist=ia;
  sprintf(out, "%s_anharmonic.dat", nameout);
  if(ia==0){file_out=fopen(out, "w");}
  else{
    file_out=fopen(out, "r");
    if(file_out){fclose(file_out); file_out=fopen(out, "a");}
    else{file_out=fopen(out, "w"); f_exist=0;}
  }
  if(f_exist==0){
    fprintf(file_out, "#1=Mode 2=1/omega 3=dKL 4=E_harmonic 5=analytic");
    fprintf(file_out, "6=c_max 7=max.rmsd 8=c_step 9=t_max 10=Ene_max\n");
  }
  fprintf(file_out, "%d\t%.3g\t%.3g\t%.3g\t%.3g\n",
	  ia, 1./omega, d_KL, E_ave_har, E_ave_anhar);
  fprintf(file_out, "%.3g\t%.3g\t%.3g\t%.3g\t%.3g\n", 
	  rmsd_max, c_max, c_step, c_step*tmax, Ene_max);
  return(d_KL);
}

int **Set_interactions(struct interaction *Int_list, int N_int,
		       atom *atoms, int nres)
{
  int **matrix=malloc(nres*sizeof (int *)); int i1, i2;
  for(i1=0; i1<nres; i1++){
    matrix[i1]=malloc(nres*sizeof(int));
    for(i2=0; i2<nres; i2++)matrix[i1][i2]=-1;
  }
  struct interaction *Int=Int_list;
  for(int n=0; n<N_int; n++){
    i1=atoms[Int->i1].res;
    i2=atoms[Int->i2].res;
    if((i1<0)||(i1>=nres)||(i2<0)||(i2>=nres)){
      printf("ERROR in Set_interactions i1=%d i2= %d nres=%d n= %d\n",
	     i1, i2, nres, n); exit(8);
    }
    matrix[i1][i2]=n;
    matrix[i2][i1]=n;
    Int++;
  }
  printf("\n%d native interactions stored\n", N_int);
  return(matrix);
}

int Interactions_CA(struct interaction *Int_list, float thr,
		    atom *atoms, int N_res, float *coord)
{
  int N_int=0, i1=0;
  float thr2=thr*thr, d, d2;

  for(int res1=0; res1<N_res; res1++){

    if(Find_CA(atoms, &i1, res1)< 0)continue;
    atom *atom1=atoms+i1; int i2=i1+1;

    for(int res2=res1+1; res2<N_res; res2++){
      if(Find_CA(atoms, &i2, res2)< 0)continue;
      atom *atom2=atoms+i2;

      // Interatomic distance
      d=atom2->r[0]-atom1->r[0]; d2 =d*d; if(d2>thr2)continue;
      d=atom2->r[1]-atom1->r[1]; d2+=d*d; if(d2>thr2)continue;
      d=atom2->r[2]-atom1->r[2]; d2+=d*d; if(d2>thr2)continue;

      // store interaction
      Int_list[N_int].i1=i1; Int_list[N_int].i2=i2;
      N_int++;
      if(N_int >= INT_MAX){
	printf("ERROR, too many interactions %d\n", N_int);
	printf("%d residues, Threshold= %.2f\n", N_res, thr);
	exit(8);
      }
    }
  }
  return(N_int);
}

int Find_CA(atom *atoms, int *i1, int res){
  atom *atom=atoms+*i1; int i=*i1;
  while(atom->res <= res){
    if((atom->res == res)&&(strncmp(atom->name, "CA", 2)==0)){
      *i1=i; return(0);
    }
    atom++;
  }
  if(atoms[*i1].res==res)return(0);
  return(-1);
}

float Min_res_dist(float *r, atom *atoms, int i1, int i2, int n)
{
  int j1=Start_res(atoms, i1), res1=atoms[j1].res;
  int j2=Start_res(atoms, i2), res2=atoms[j2].res;
  float *r1=r+3*j1, *r2;

  float d, d2, d2_min=1000;
  while(atoms[j1].res==res1){
    r2=r+3*j2; int jj2=j2;
    while(atoms[jj2].res==res2){
      d=r1[0]-r2[0]; d2 =d*d; if((n<0)&&(d2>rep_thr2))goto next;
      d=r1[1]-r2[1]; d2+=d*d; if((n<0)&&(d2>rep_thr2))goto next;
      d=r1[2]-r2[2]; d2+=d*d; if((n<0)&&(d2>rep_thr2))goto next;
      if(d2<d2_min)d2_min=d2;
    next:
      r2+=3; jj2++;
    }
    r1+=3; j1++;
  }
  if((d2_min<=rep_thr2)||(n>=0))return(sqrt(d2_min));
  return(0);
}

int Start_res(atom *atoms, int i){
  if(atoms[i-1].res==atoms[i].res)return(i-1);
  return(i);
}

float Energy_anharmonic(float *r, atom *atoms, int nres,
			struct interaction *Int_list, int N_int)
{
  // Auxiliary matrices for energy computation: interaction list
  if(INI_RES_RES==0){
    INI_RES_RES=1;
    E_repulsion=Int_list[0].A;
    rep_thr=4.5;  rep_thr2=rep_thr*rep_thr;
    int_res1_res2=Set_interactions(Int_list, N_int, atoms, nres);
    INT_MAX=150*nres;
    Int_list_ini=malloc(INT_MAX*sizeof(struct interaction));
    Int_list_tmp=malloc(INT_MAX*sizeof(struct interaction));
    N_int_ini=Interactions_CA(Int_list_ini, d_CA_high, atoms, nres, r);
    N_int_tmp=N_int_ini;
    for(int i=0; i<N_int_tmp; i++)Int_list_tmp[i]=Int_list_ini[i];
    lambda2=2*lambda;
  }

  double E_sum=0, rep, attr; int n_attr=0, n_rep=0;
  for(int i=0; i<N_int_tmp; i++){
    int i1=Int_list_tmp[i].i1, i2=Int_list_tmp[i].i2;
    int n=int_res1_res2[atoms[i1].res][atoms[i2].res];
    if(n>=0)n_attr++;
    float d=Min_res_dist(r, atoms, i1, i2, n);
    if(d==0)continue;
    if(n>=0){
      if(POW){attr=pow(d,-lambda);}
      else{attr=exp(-lambda*d);}
      E_sum-=Int_list[n].B*attr;
      n_rep++; 
    }
    if(d<rep_thr){
      if(n>=0){rep=attr*attr;}
      else if(POW){rep=pow(d,-lambda2);}
      else{rep=exp(-lambda2*d);}
      E_sum+=E_repulsion*rep;
      n_rep++;
    }
  }
  printf("%d tested interactions %d attract. %d repulsion found E= %.3g\n",
	 N_int_tmp, n_attr, n_rep, E_sum);
  printf("d_thr= %.2f\n", sqrt(rep_thr2));
  exit(8);
  return(E_sum);
}

