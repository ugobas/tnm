float Mammoth_ali(int *aligned, int *seq_id, float *psi, int *alignres, 
		  struct chain *chp1, struct residue *seq1, 
		  struct chain *chp2, struct residue *seq2);
