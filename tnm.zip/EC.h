float *EC_profile(float *PE, double **Mat, int N, char *name);
float *CV_profile(double **Corr, int N);
float *Weighted_flux(double **Corr_in, int N, int IJMIN, char *name);
