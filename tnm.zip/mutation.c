#include "coord.h"
#include "tnm.h"
#include "nma.h"
#include "nma_para.h"
#include "allostery.h"
#include "mutation.h"
#include "contacts.h"
#include "vector.h"
#include "atom_numb.h"
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "allocate.h"
#include "contacts.h"
#include "Residues_distances.h"

int FORCE_TYPE=0;
/* Compute force based on size(0), stability (1), optimal distance (2)
   or combination of size and distance (3)? */
float EXP_FORCE=0, Exp;
int NPAR1=5, NPAR2=4;
float CL_THR=0.01; // Minimal collectivity of normal modes to predict mut
float C_SIZE=0.0009, C_STAB, C_DIST; //C_STAB=0.035
float RATIO_D=20; // Initial value of C_DIST/C_SIZE RATIO=20; 
float RATIO_S=22; // Initial value of C_STAB/C_SIZE RATIO=20; 

int ncmax=100; 
int mut_cont[100], wt_cont[100];
int mut_res[100], wt_res[100];

int Mutation_force(float *Force, int N_Cart,
		    int *Posmut, char *AAmut, int Nmut,
		    int **clist, int **cnum,
		    struct interaction *Int_list,
		    struct residue *seq, atom *atoms,
		    struct Reference Ref_kin, int *kin_atom, char *mut);

void Compute_mut_def(float *mut_Cart, int N_Cart,
		     float *mut_Tors, int N_axes,
		     float *Force, struct Normal_Mode NM, float mass,
		     char *nameout1, int kmod);

float *Convert_to_tors(float *Cart, int N3, float **J_ar, int N_axes);
void  Match_atoms(int *ref_atom, atom *atoms, int natoms,
		  int *atom_ref, int N_ref);

int Mutation(float *mut_Tors_out, int N_axes, float *mut_CC_out,
	     struct Reference Ref_kin, 
	     int Nmut, int *Posmut, char *AAmut, int Force_type,
	     struct Normal_Mode NM, atom *atoms, int natoms,
	     struct interaction *Int_list, int N_int,
	     struct residue *seq,
	     float *B_pred,
	     float *Confchange_Cart, struct Reference Ref_CC,
	     float *Confchange_Tors, float *Tors_fluct,
	     char *nameout1)
{
  // Determine mutations
  if(Nmut==0){
    printf("Sorry, no mutation is present to predict its effect\n");
    return(0);
  }

  printf("Examining the effect of mutations: ");
  // Interactions directed along representative atoms
  int Nres=atoms[Ref_kin.atom_num[Ref_kin.N_ref-1]].res+1;
  int i, imut=1;
  for(i=0; i<Nmut; i++){
    printf(" %c%d%c", seq[Posmut[i]].amm, Posmut[i], AAmut[i]);
    int aam=Code_AA(AAmut[i]);
    if((Posmut[i]<0)||(Posmut[i]>=Nres)||(aam<0)||(aam>19)){
      printf("\nWARNIG mutation does not exist (only %d residues)\n", Nres);
      imut=0;
    }
  }
  printf("\n");
  if(imut==0)return(0);


  /* Three nested sets of atoms:
     - All (compute interactions)
     - kin (Cartesian normal modes) -> kin_atom
     - CC  (Conformation change)    -> cc_kin
     - res (one per residue) -> B_fact
     The Cartesian force is computed for kin atoms and
     projected onto normal modes to obtain the torsional force
  */
  int N_kin=Ref_kin.N_ref, N_Cart=3*N_kin;
  // Match any atom to closest kinetic atom
  int kin_atom[natoms]; 
  Match_atoms(kin_atom, atoms, natoms, Ref_kin.atom_num, N_kin);
  // Extract one reference atom per residue
  char SEL[4]="CA"; if(strcmp(REF_CC, "CB")==0)strcpy(SEL, "CB");

  /*float mass=0; int i_kin[Nres], resatom[Nres], atomres[Nres];
  int Na=Extract_atoms(i_kin,iatom,atomres,seq,&mass,atoms,Ref_kin,SEL);
  // iref[a]: kinetic atom of residue a
  // atomres[a]: residue number */

  // Contact list
  int *nc, **clist, **cnum;
  Get_contact_list(&nc, &clist, &cnum, Nres, atoms, Int_list, N_int);

  // Selected force 
  int N_FORCE=4; // Allowed FORCE_TYPE: 0 ... N_FORCE-1
  if(Force_type >=N_FORCE){
    printf("WARNING, not allowed MUT_FORCE, using default\n");
    Force_type=FORCE_TYPE;
  }

  // resatom[ia]= Reference atom for residue ia
  int Na=0, j, resatom[Nres]; double RMSD=0;
  // Structural deformation profile for resatom
  float strdiff_abs2[Nres], strdiff_3[3*Nres], *str=strdiff_3;
  for(i=0; i<Ref_CC.N_ref; i++){
    atom *atm=atoms+Ref_CC.atom_num[i];
    if((strncmp(atm->name, SEL, 2)!=0)&&
       ((seq[atm->res].amm!='G')||(strncmp(atm->name, "CA", 2)!=0)))continue;
    resatom[Na]=Ref_CC.atom_num[i];
    double d=0; float *x=Confchange_Cart+3*i;
    for(j=0; j<3; j++){*str=*x; d+=(*x)*(*x); x++; str++;}
    strdiff_abs2[Na]=d; RMSD+=d; 
    Na++;
  }
  RMSD=sqrt(RMSD/Na);
  if(Na!=Nres)printf("WARNING, %d residues expected, %d found\n", Nres, Na);
  if(Na > Nres){printf("Leaving\n"); return(0);} 
  printf("RMSD= %.2f\n", RMSD);
  int Na3=3*Na;

  // Exponent of the force computation
  Exp=(1.+EXP_FORCE)/2;

  // Output
  char nameout[200]; FILE *file_out;
  sprintf(nameout, "%s_mutation.dat", nameout1);
  file_out=fopen(nameout, "w");
  printf("Writing %s\n", nameout);
  fprintf(file_out, "# RMSD= %.2f N= %d residues n= %d kinetic atoms\n",
	  RMSD, Nres, Ref_kin.N_ref);
  fprintf(file_out, "# Exponent of the force: -%.1f\n", EXP_FORCE);
  fprintf(file_out, "# Prediction based on %d mutations: ", Nmut);
  for(int ia=0; ia<Nmut; ia++){
    int i=Posmut[ia];
    fprintf(file_out, "%c%d%c", seq[i].amm, i, AAmut[ia]);
    if(ia < (Nmut-1))fprintf(file_out, "_");
  }
  fprintf(file_out, "\n");

  if(Nres!=Na)fprintf(file_out, "# gap= %d residues\n", Nres-Na);
  float slope, offset;
  float r_CC_B=Corr_coeff(B_pred, strdiff_abs2, Na, &slope, &offset);
  fprintf(file_out,
	  "# Correlation predicted_B_factors confchange: %.3f",r_CC_B);
  fprintf(file_out, " slope= %.3g offset= %.3g\n", slope, offset);
  //Correlation predicted_mutation confchange (torsional):
  float r=Corr_coeff(Tors_fluct, Confchange_Tors, N_axes, &slope, &offset);
  fprintf(file_out, "# Correlation predicted_Tors_fluct Tors_confchange: ");
  fprintf(file_out, "%.3f slope=%.2g offset=%.2g\n", r, slope, offset);

  fprintf(file_out, "# Pred.force directed along axes between kinetic atoms\n");
  fprintf(file_out, "#1=type 2=RMSD 3=RMSD_pred ");
  fprintf(file_out, "4=Correlation(pred_mut2,confchange2) 5=slope 6=offset ");
  fprintf(file_out, "7=Correlation(pred_mut2,pred_B) "); 
  fprintf(file_out, "8=Partial_correlation(pred_mut2,confchange) ");
  fprintf(file_out, "9=Correlation(pred_mut,confchange)_Cart 10=slope 11=off ");
  fprintf(file_out, "12=Correlation(pred_mut,confchange)_tors ");
  fprintf(file_out, "13=slope 14=offset\n");

  char mut_type[400]; int kmod=0; float r_max=-100;
  for(int iforce=0; iforce<N_FORCE; iforce++){
    int n1=1, n2=1; C_DIST=C_SIZE*RATIO_D; // 16 8 4 2 1 
    sprintf(mut_type, "Predicted mut based on changes of");
    if(iforce==0){
      sprintf(mut_type, "%s size, only s.c. contacts", mut_type);
    }else if(iforce==1){
      sprintf(mut_type, "%s stability", mut_type);
    }else if(iforce==2){
      sprintf(mut_type, "%s opt_distance", mut_type);
    }else if(iforce==3){
      sprintf(mut_type,
	      "%s size for s.c. and opt_distance for m.c. contacts", mut_type);
      n1=NPAR1; n2=NPAR2;
    }
    FORCE_TYPE=iforce;
    
    // Compute the force due to the mutation
    fprintf(file_out, "# %s\n", mut_type);
    for(int k1=0; k1<n1; k1++){
      C_STAB=C_SIZE*RATIO_S;
      for(int k2=0; k2<n2; k2++){

	// Compute force
	float Force[N_Cart];
	int n=Mutation_force(Force, N_Cart, Posmut, AAmut, Nmut, clist, cnum,
			     Int_list, seq, atoms, Ref_kin, kin_atom, mut_type);

	// Compute deformation mut_Cart and mut_Tors
	float mut_Cart[N_Cart], mut_Tors[N_axes];
	Compute_mut_def(mut_Cart, N_Cart, mut_Tors, N_axes,
			Force, NM, Ref_kin.mass_tot, nameout1, kmod);
      
	// Deformation of resatom mut_3, mut_abs2 and RMSD_pred
	float mut_abs2[Na], mut_3[Na3]; 
	double RMSD_pred=0; int ia=0; str=mut_3;
	for(i=0; i<Na; i++){
	  float *x=mut_Cart+3*kin_atom[resatom[i]]; double d=0;
	  for(j=0; j<3; j++){*str=*x; d+=(*x)*(*x); x++; str++;}
	  mut_abs2[i]=d; RMSD_pred+=d;
	}
	RMSD_pred=sqrt(RMSD_pred/Na);
	printf("Predicted RMSD= %.2f\n", RMSD_pred);

	// Printing
	// Print contacts
	if((k1==0)&&(k2==0)){
	  fprintf(file_out, "# Prediction based on %d contacts: ", n);
	  for(i=0; i<n; i++){
	    fprintf(file_out, " %c%d-%c%d",
		    AA_code[wt_cont[i]], wt_res[i],
		    AA_code[mut_cont[i]], mut_res[i]);
	    if(i==ncmax)break;
	  }
	  fprintf(file_out, "\n");
	}
	// Print parameters
	if(iforce==0){
	  fprintf(file_out, "# C_SIZE= %.2g\n", C_SIZE);
	}else if(iforce==1){
	  fprintf(file_out, "# C_STAB= %.2g\n", C_STAB);
	}else if(iforce==2){
	  fprintf(file_out, "# C_DIST= %.2g\n", C_DIST);
	}else{
	  fprintf(file_out,
		"# C_DIST/C_SIZE= %.3f C_STAB/C_SIZE= %.3f\n",
		  C_DIST/C_SIZE, C_STAB/C_SIZE);
        }

	fprintf(file_out, "%d\t%.2f\t%.2f", kmod, RMSD, RMSD_pred); kmod++;
	float r_CC_A=Corr_coeff(mut_abs2, strdiff_abs2, Na, &slope, &offset);
	fprintf(file_out, "\t%.3f\t%.3g\t%.3g", r_CC_A, slope, offset);
	printf("Correlation predicted_mutation confchange (abs): %.3f\n",
	       r_CC_A);
	float r_A_B=Corr_coeff(B_pred, mut_abs2, Na, &slope, &offset);
	fprintf(file_out,"\t%.3f", r_A_B);
	//fprintf(file_out, "\t%.3g\t%.3g\n", slope, offset);
	//Partial correlation predicted_mut confchange| B_pred:
	float rp=(r_CC_A-r_CC_B*r_A_B)/sqrt((1-r_CC_B*r_CC_B)*(1-r_A_B*r_A_B));
	fprintf(file_out, "\t%.3f", rp);

	/*double sum_mc=0, sum_m2=0, sum_c2=0;
	  float *m=mut_3, *c=strdiff_3;
	  for(i=0; i<Na3; i++){
	  sum_mc+=(*m)*(*c);
	  sum_m2+=(*m)*(*m);
	  sum_c2+=(*c)*(*c);
	  m++; c++;
	  }
	if(sum_m2)sum_mc/=sqrt(sum_m2*sum_c2);
	float scale=sqrt(sum_c2/sum_m2);
	fprintf(file_out, "\t%.3f\t%.2g", sum_mc, scale); */
	
	//Correlation predicted_mutation confchange (Cartesian):
	float r=Corr_coeff(mut_3, strdiff_3, Na3, &slope, &offset);
	fprintf(file_out, "\t%.3f\t%.2g\t%.2g", r, slope, offset);

	// Output
	if(r>r_max){
	  r_max=r;
	  // Deformation of reference atoms mut_CC (output)
	  float *m_CC=mut_CC_out;
	  for(i=0; i<Ref_CC.N_ref; i++){
	    float *x=mut_Cart+3*kin_atom[Ref_CC.atom_num[i]];
	    for(int j=0; j<3; j++){*m_CC=*x; x++; m_CC++;}
	  }
	  for(i=0; i<N_axes; i++)mut_Tors_out[i]=mut_Tors[i];
	}

	//Correlation predicted_mutation confchange (torsional):
	float mut_t2[N_axes];
	for(i=0; i<N_axes; i++)mut_t2[i]=mut_Tors[i]*mut_Tors[i];
	r=Corr_coeff(mut_t2, Confchange_Tors, N_axes, &slope, &offset);
	fprintf(file_out, "\t%.3f\t%.2g\t%.2g", r, slope, offset);
	fprintf(file_out, "\n");
	
	//"# Correlation mut predicted_fluct (torsional): %.3f",r);
	//r=Corr_coeff(Tors_fluct, mut_Tors, N_axes, &slope, &offset);
	//fprintf(file_out, "\t%.3f\t%.2g\t%.2g", r, slope, offset);
	
	if(1){
	  fprintf(file_out, "# 1=observed_confchange 2=predicted_flexibility");
	  fprintf(file_out, " 3=predicted_confchange 4=force");
	  fprintf(file_out, " pos aa\n");
	  for(ia=0; ia<Na; ia++){
	    fprintf(file_out, "%.3f %.3f", strdiff_abs2[ia], B_pred[ia]);
	    fprintf(file_out, " %.3g", mut_abs2[ia]);
	    double F=0;
	    for(int j=ia*3; j<(ia+1)*3; j++)F+=Force[j]*Force[j];
	    fprintf(file_out, " %.3g", F);
	    int a=atoms[resatom[ia]].res;
	    fprintf(file_out, " %s %c", seq[a].pdbres, seq[a].amm);
	    fprintf(file_out, "\n");
	  }
	}
	if(0){
	  printf("Force: ");
	  for(i=0; i<N_Cart; i++)printf(" %.2f", Force[i]); printf("\n");
	  printf("mut_Cart: ");
	  for(i=0; i<N_Cart; i++)printf(" %.2f", mut_Cart[i]); printf("\n");
	  printf("mut_CC: ");
	  for(i=0; i<Ref_CC.N_cart; i++)printf(" %.2f", mut_CC_out[i]);
	  printf("\n");
	  printf("mut_Tors: ");
	  for(i=0; i<N_axes; i++)printf(" %.2f", mut_Tors_out[i]); printf("\n");
	  exit(8);
	}
	C_STAB/=2;
      }// end C_STAB
      C_DIST/=2;
    }// end C_DIST
  } // end iforce

  fclose(file_out);
  Empty_matrix_i(clist, Nres);
  Empty_matrix_i(cnum, Nres); free(nc);
  return(1);
}

int Mutation_force(float *Force, int N3,
		   int *Posmut, char *AAmut, int Nmut,
		   int **clist, int **cnum,
		   struct interaction *Int_list,
		   struct residue *seq, atom *atoms,
		   struct Reference Ref_kin,
		   int *kin_atom, char *mut)
{

  printf("Computing perturbation caused by mutation based on %s\n", mut);
  int am=-1, ai, j, nc=0; double dsize=0;
  for(j=0; j<N3; j++)Force[j]=0;
  for(int kmut=0; kmut<Nmut; kmut++){
    int pmut=Posmut[kmut];
    int *ic=clist[pmut]; // residue in contact with pmut
    int *ii=cnum[pmut];  // interaction label of the contact
    int aaw=Code_AA(seq[pmut].amm); // wild-type aa
    int aam=Code_AA(AAmut[kmut]);   // mutated aa
    dsize=(atom_numb[aam]-atom_numb[aaw]);

    while(*ic >= 0){
      //if(abs(pmut-(*ic))<3)goto next; // short range contact discarded
      int i1=Int_list[*ii].i1, i2=Int_list[*ii].i2;
      if(atoms[i1].res==pmut){
	am=i1; ai=i2;
      }else if(atoms[i2].res==pmut){
	am=i2; ai=i1;
      }else{
	printf("ERROR in mutation, interaction %d res %d - %d pmut= %d\n",
	       *ii, atoms[i1].res, atoms[i2].res, pmut); exit(8);
      }
      // contacts of main chain atoms of mutant residue are discarded (?)
      int mainchain=0;
      if((strncmp(atoms[am].name,"N ",2)==0)||
	 (strncmp(atoms[am].name,"C ",2)==0)||
	 (strncmp(atoms[am].name,"O ",2)==0))mainchain=1;
      if(mainchain)goto next; //&& FORCE_TYPE!=3
      int res_i=atoms[ai].res;
      //if((abs(res_i-pmut)<3))goto next; //&&(FORCE_TYPE==1)
      int aai=Code_AA(seq[*ic].amm);
      if(nc<ncmax){
	mut_cont[nc]=aai; mut_res[nc]=res_i;
	wt_cont[nc]=aaw; wt_res[nc]=pmut;
      }
      nc++;

      float *rm=atoms[am].r, *ri=atoms[ai].r;
      float r[3], r2=0;
      for(j=0; j<3; j++){
	r[j]=rm[j]-ri[j]; r2+=r[j]*r[j];
      }
      r2=pow(r2, Exp);
      float f=0;
      if(FORCE_TYPE==0){
	if(dsize){f=C_SIZE*dsize;}
	else{f=C_DIST*(D_Residues[aam][aai]-D_Residues[aaw][aai]);}
      }else if(FORCE_TYPE==1){
	f=C_STAB*(Econt[aam][aai]-Econt[aaw][aai]);
      }else if(FORCE_TYPE==2){
	f=C_DIST*(D_Residues[aam][aai]-D_Residues[aaw][aai]);
      }else{
	f =C_DIST*(D_Residues[aam][aai]-D_Residues[aaw][aai]);
	f+=C_SIZE*dsize;
	f+=C_STAB*(Econt[aam][aai]-Econt[aaw][aai]);
      }
      f/=r2;
      int km=3*kin_atom[am], ki=3*kin_atom[ai]; 
      for(j=0; j<3; j++){
	float fj=f*r[j];
	Force[km+j]+=fj; //?
	Force[ki+j]-=fj;
      }
    next:
      ic++; ii++;
    }
  }
  printf("Force computation based on %d contacts\n", nc);
  return(nc);
}

void Compute_mut_def(float *mut_Cart, int N_Cart,
		     float *mut_Tors, int N_axes,
		     float *Force, struct Normal_Mode NM, float mass,
		     char *nameout1, int kmod)
{
  int a, i;
  for(i=0; i<N_Cart; i++)mut_Cart[i]=0;
  for(i=0; i<N_axes; i++)mut_Tors[i]=0;

  double F=0;
  for(i=0; i<N_Cart; i++){F+=Force[i]*Force[i];}
  printf("RMS of mutational force: %.3f\n", sqrt(3*F/N_Cart));

  // Compute predicted deformation of kinetic atoms (Cart)
  float coeff[NM.N_relevant];
  for(a=0; a<NM.N_relevant; a++){
    //if(NM.contr2fluct[a]==0)continue;
    if((NM.Cart_coll[a]<CL_THR)||(NM.omega2[a]<=0)){coeff[a]=0; continue;}
    float *f=Force, *x=NM.Cart[a];
    double xf=0; // Projection of force on normal mode
    for(i=0; i<N_Cart; i++){xf+=(*x)*(*f); x++; f++;}
    xf*=(mass/NM.omega2[a]);
    coeff[a]=xf;
    float *m=mut_Cart; x=NM.Cart[a];
    for(i=0; i<N_Cart; i++){
      (*m)+=(*x)*xf; x++; m++;
    }
    m=mut_Tors; x=NM.Tors[a];
    for(i=0; i<N_axes; i++){
      (*m)+=(*x)*xf; x++; m++;
    }
  }

  if(1){
    int N_print=30; char nameout[200];
    sprintf(nameout, "%s_mutation_%d.dat", nameout1, kmod);
    FILE *file_out=fopen(nameout, "w");
    printf("Writing %s\n", nameout);
    float kappa=Collectivity_norm2(Force, N_Cart);
    fprintf(file_out, "# Collectivity of force: %.2f\n", kappa/3);
    fprintf(file_out,"#mod contr2fluct contr2cc contr2force collectivity\n");
    double sum=0;
    for(a=0; a<NM.N_relevant; a++){coeff[a]*=coeff[a]; sum+=coeff[a];}
    for(a=0; a<N_print; a++){
      fprintf(file_out, "%d\t%.4f\t%.4f\t%.4f\t%.3f\n", //
	      a, NM.contr2fluct[a], NM.confchange2[a],
	      coeff[a]/sum, NM.Cart_coll[a]);
    }
    fclose(file_out);
  }

}

float *Convert_to_tors(float *Cart, int N3, float **J_ar, int N_axes)
{
  // Torsional force = J^t f = sum_i dr_i/dphi_a f_i
  float *Tors=malloc(N_axes*sizeof(float)); int a, i;
  for(a=0; a<N_axes; a++){
    double sum=0; float *J=J_ar[a], *f=Cart;
    for(i=0; i<N3; i++){sum+=(*J)*(*f); J++; f++;}
    Tors[a]=sum;
  }
  return(Tors);
}

void  Match_atoms(int *ref_atom, atom *atoms, int natoms,
		  int *atom_ref, int N_ref)
{
  /* For every atom i=1,natoms ref_atom[i] is the index of the reference
     atom that is closest to i */
  int i; for(i=0; i<natoms; i++)ref_atom[i]=-1;
  for(i=0; i<N_ref; i++)ref_atom[atom_ref[i]]=i;
  int Nr1=N_ref-1, ini_r=0, n=0;
  for(i=0; i<natoms; i++){
    if(ref_atom[i]>=0)continue; n++;
    atom *atom=atoms+i, *atom2;
    while((ini_r<Nr1)&&(atoms[atom_ref[ini_r]].res<atom->res))ini_r++;
    if(atoms[atom_ref[ini_r]].res != atom->res){
      printf("ERROR unmatch_atom in residue %c%d\n", atom->aa, atom->res);
      exit(8);
    }
    float d2_min=1000; int ir=ini_r, ir_min=-1;
    while(ir<N_ref){
      atom2=atoms+atom_ref[ir];
      if(atom2->res==atom->res){
	float d2=Distance_square(atom->r, atom2->r);
	if((d2<d2_min)||(ir_min<0)){d2_min=d2; ir_min=ir;}
      }
      ir++;
    }
    if(ir_min<0){
      printf("ERROR, reference atom %d in atom %d residue %c%d not valid\n",
	     ir_min, i, atom->aa, atom->res);
    }
    ref_atom[i]=ir_min;
  }
  if((N_ref+n)!=natoms){
    printf("ERROR, N_ref+%d=%d atoms matched over %d\n",
	   n, N_ref+n, natoms); exit(8);
  }
  if(0){
    for(i=0; i<natoms; i++){
      atom *atom=atoms+i;
      printf("%d %s(%c%d) ", i, atom->name, atom->aa, atom->res);
      int j=atom_ref[ref_atom[i]]; atom=atoms+j;
      printf(" ref: %d  %s(%c%d)\n", j, atom->name, atom->aa, atom->res);
    }
    exit(8);
  }
}
