// Parameters for interactions

int S_TYPE;        // Type of shadow interaction
int ONEINT;        // Only one interaction per atom vs. residue
float C_THR;       // Threshold for contacts;
float S_THR;       // Screening parameter
int HNM;           // Calpha interactions with Hissen parameters
int NOCOV;         // Covalent neighbors do not interact
char REF[20];      // Reference atoms
int N_RESRES;      // Number of interactions retained for each residue pair

void Compute_interactions(int *N_int, struct interaction **Int_list,
			  char *INT_TYPE, atom *atoms1, int natoms1, int nres1);
/*int Interactions_shadow(struct interaction *Int_list, float THR,
			atom *atoms, int N_atoms,
			int TYPE, float S_THR, int NOCOV);*/
int Screened_Interactions(struct interaction *Int_list,
			  float THR, atom *atoms, int N_atoms, int nres,
			  int TYPE, float DELTA_SCR);

void Print_contact_matrix(struct interaction *Int_list, int N_int,
			  atom *atoms, struct residue *res,
			  char *name, char *pdb);
int Covalent(int res1, int res2, atom *atom1, atom *atom2);
int Bond(int res3, int res1, float d2_13, int res2, float d2_23);
void Scale_interactions(char *INT_TYPE, atom *atoms, int natoms, int nres);
struct interaction *Check_pair(int *new1, int res1, int *res2, int nres,
			       struct interaction **ini,
			       struct interaction *end);
