extern int Verbose;
extern char cont_type;
extern float cont_thr, cont_thr2;
extern char *AA_code;
